# Explicación del proyecto: Beneficios Caja de ANDE

## 1. Qué es el proyecto

Es una página web adaptable, para computadora y celular, que muestra los **beneficios comerciales** que tienen los tarjetahabientes de Caja de ANDE. La información de los 20 comercios no está escrita en el HTML. Se lee del archivo local `public/beneficios.json` con `fetch`, y React genera toda la interfaz a partir de esos datos.

**Secciones, en orden:**

1. **Header fijo**: los dos logos y el menú. Se queda arriba al hacer scroll y marca con una línea blanca la sección en la que está el usuario.
2. **Inicio (Welcome)**: título, descripción, tres indicadores con icono (calculados del JSON) y el video de tarjetas.
3. **Destacado**:
   - Izquierda: banner de la mujer con tarjeta, con el título "Descuentos y promociones especiales" encima y una mini tarjeta de un comercio.
   - Derecha, arriba (35%): cintillo `<marquee>` con los comercios, cada uno en una tarjeta blanca con su logo y nombre.
   - Derecha, abajo (65%): el beneficio con mayor descuento, con logo, categoría, descripción, imagen y la etiqueta "Hasta X%". El botón filtra la lista por su categoría.
4. **Categorías**: franja con iconos y la opción "Todos". En móvil hace scroll horizontal.
5. **Beneficios**: título, contador, buscador debajo del título y las 20 tarjetas (4 por fila en escritorio, 1 en móvil). El botón "Ver todos los beneficios" quita el filtro y la búsqueda.
6. **Footer**: logos, enlaces, redes sociales en círculos y el total real de beneficios cargados.

---

## 2. Qué se usó

| Tecnología | Para qué |
|---|---|
| **React 18** | Componentes, estado y renderizado de la interfaz |
| **Vite** | Servidor de desarrollo (`npm run dev`) y build |
| **Bootstrap 5.0.2 (CDN)** | Grid responsive, navbar colapsable, cards, alertas y botones |
| **CSS propio** (`src/index.css`) | Colores de marca, tarjetas, cintillo, destacado y footer |
| **fetch + JSON** | Lectura de `beneficios.json` |
| **IntersectionObserver** | Detectar la sección visible y marcarla en el menú |
| **SVG inline** | Iconos de los indicadores, del buscador y de "Todos" |

**Colores:** azul `#003fb7` (marca), amarillo `#ffc900` (acento) y fondo `#f4f7fb`.

---

## 3. Estructura de componentes

```
App.jsx                  → estado global, fetch, filtros
├── Header.jsx           → navbar fija + línea en la sección activa
├── Welcome.jsx          → hero, indicadores con icono y video
├── Promo.jsx            → banner con texto, cintillo y destacado
├── Categorias.jsx       → franja de filtros
├── ListaBeneficios.jsx  → buscador, contador, "ver todos" y grid
│   └── TarjetaBeneficio.jsx
├── Footer.jsx
└── ImagenSegura.jsx     → <img> con manejo de error (se usa en todos)
```

---

## 4. Cómo explicarlo en la demostración (unos 2 minutos)

**1. Carga del JSON**
> "En `App.jsx` uso un `useEffect` que se ejecuta una vez al cargar. Adentro hago `fetch` a `beneficios.json`, reviso `res.ok`, convierto a JSON y lo guardo en el estado con `setBeneficios`. Todo va en un `try/catch`. Si falla, guardo un mensaje de error y se muestra una alerta de Bootstrap. También tengo un estado `cargando` para mostrar 'Cargando...' mientras llega la información."

**2. Generación de tarjetas**
> "Las tarjetas no están escritas a mano. `ListaBeneficios` recorre el arreglo con `.map()` y crea un componente `TarjetaBeneficio` por cada registro, usando el `id` como `key`. El cintillo, las categorías y el destacado también salen del mismo JSON."

**3. Datos calculados**
> "Con `useMemo` calculo las categorías únicas con un `Set`, los indicadores (total, categorías y promociones con %), el beneficio destacado (el de mayor porcentaje) y la lista filtrada. Así no copio ninguna cifra a mano."

**4. Filtro, búsqueda y ver todos**
> "La categoría seleccionada y el texto de búsqueda son estados. La lista visible se filtra por los dos, sin importar tildes ni mayúsculas. El contador dice 'Mostrando X de 20', así que refleja lo visible. El botón 'Ver todos' limpia ambos filtros."

**5. Diseño adaptable**
> "Uso el grid de Bootstrap: `row-cols-1 row-cols-sm-2 row-cols-lg-4` da 1, 2 o 4 tarjetas por fila. La navbar se colapsa en móvil y se cierra sola al elegir una opción. La sección destacada usa `col-12 col-lg-6`, o sea dos columnas en escritorio y apiladas en móvil. Las categorías tienen scroll horizontal."

**6. Errores y accesibilidad**
> "Hice un componente `ImagenSegura` que escucha `onError`: si una imagen falla, muestra un respaldo, la oculta o muestra el nombre en texto, según el caso. Todos los controles son botones o enlaces reales, se usan con Tab y tienen el foco visible en amarillo. El buscador tiene `label` y los contadores tienen `aria-live`."

---

## 5. Preguntas que te pueden hacer

**¿Por qué React y no HTML puro?**
Porque la interfaz depende de datos: cuando cambia el estado (el filtro o la búsqueda), React vuelve a pintar solo lo necesario. Además, separar en componentes deja el código más ordenado y reutilizable.

**¿Por qué el JSON está en `public/`?**
Vite sirve esa carpeta en la raíz, así que `fetch('/beneficios.json')` funciona como si fuera un archivo de un servidor.

**¿Por qué no se puede abrir con doble clic?**
Con `file://` el navegador bloquea `fetch`. Por eso se corre con `npm run dev`.

**¿Qué pasa si un recurso externo no carga?**
`ImagenSegura` lo maneja. Por ejemplo, el logo de "Colchones Selther" viene sin extensión en el JSON; si no carga, se muestra la inicial del comercio.

**¿Qué es `useMemo`?**
Guarda un cálculo y solo lo repite cuando cambian sus dependencias. Evita recalcular el filtro en cada render.

**¿Cómo funciona la línea del menú?**
Un `IntersectionObserver` detecta qué sección está en el centro de la pantalla y le agrega la clase `activo` al enlace. Esa clase dibuja la línea blanca con un `::after` en CSS.

---

## 6. Cómo correrlo

```bash
npm install
npm run dev
```
Luego abrir http://localhost:5173. Para ver la vista móvil: F12 → modo dispositivo → unos 390 px de ancho.
