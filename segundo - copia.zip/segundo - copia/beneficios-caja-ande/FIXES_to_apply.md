- nav bar should be fix on all the navigation
= white line when a section is on _ like beneficios then beneficios is wiht a line bellow the lettrs 

- add icons to the 3 benefit on the welcome section 
- move the section cateogries bellow section destacado

- for the section destacado check the img fro referene on the carpet /recom 
- you can use recom as guidance for further fixes however we need to have a diff style wihch is better 
- i like cintillo but i want to have like a white card background behind each comercio afiliado also make that bigger like a 35 65% regardint eh other div destacado de one with the beneficio destacada
- add some text to the img big on 

- section benefits i want to have the search bar bellow the tittle not on the site an dthe befefit bellow also a a html to shouw again all benefists pleas e

- add a new md explaining what is the project about, what did you use and how to explian this 
fix the footer as the references img on /recom


= please use this if possible 

RECURSOS VISUALES — PRUEBA TÉCNICA BENEFICIOS

Estos recursos se consultan por URL. No se incluyen como archivos descargados.
Las imágenes de los comercios se referencian desde beneficios.json.


Header - Nav
logos/Logocajadeande.png: https://storageproyectosmercadeo.blob.core.windows.net/masaccesosbeneficios/banners/Logocajadeande.png
logos/Beneficios.png: https://storageproyectosmercadeo.blob.core.windows.net/masaccesosbeneficios/banners/Beneficios.png

Hero
video/carrusel_tarjetas_2.mp4: https://storageproyectosmercadeo.blob.core.windows.net/masaccesosbeneficios/banners/carrusel_tarjetas_2.mp4

Contenedor mujer tarjeta y cintillo
banners/Mujertarjetabeneficios.png: https://storageproyectosmercadeo.blob.core.windows.net/masaccesosbeneficios/banners/Mujertarjetabeneficios.png

Categorías
Icono Todos (SVG):
<svg viewBox="0 0 24 24" role="img" focusable="false"><circle cx="12" cy="12" r="7.5" fill="none" stroke="currentColor" stroke-width="1.8"></circle><circle cx="12" cy="12" r="2.8" fill="currentColor"></circle></svg>
iconos/Automotriz.png: https://storageproyectosmercadeo.blob.core.windows.net/masaccesosbeneficios/iconos/Automotriz.png
iconos/Deporte.png: https://storageproyectosmercadeo.blob.core.windows.net/masaccesosbeneficios/iconos/Deporte.png
iconos/Entretenimiento.png: https://storageproyectosmercadeo.blob.core.windows.net/masaccesosbeneficios/iconos/Entretenimiento.png
iconos/Hogar.png: https://storageproyectosmercadeo.blob.core.windows.net/masaccesosbeneficios/iconos/Hogar.png
iconos/Mascotas.png: https://storageproyectosmercadeo.blob.core.windows.net/masaccesosbeneficios/iconos/Mascotas.png
iconos/Modayestilo.png: https://storageproyectosmercadeo.blob.core.windows.net/masaccesosbeneficios/iconos/Modayestilo.png
iconos/Restaurantes.png: https://storageproyectosmercadeo.blob.core.windows.net/masaccesosbeneficios/iconos/Restaurantes.png
iconos/Salud.png: https://storageproyectosmercadeo.blob.core.windows.net/masaccesosbeneficios/iconos/Salud.png
iconos/Serviciosespecializados.png: https://storageproyectosmercadeo.blob.core.windows.net/masaccesosbeneficios/iconos/Serviciosespecializados.png
iconos/Tecnologia.png: https://storageproyectosmercadeo.blob.core.windows.net/masaccesosbeneficios/iconos/Tecnologia.png

Redes sociales
redes/Facebook.png: https://storageproyectosmercadeo.blob.core.windows.net/masaccesosbeneficios/iconos/Redessociales/Facebook.png
redes/Instagram.png: https://storageproyectosmercadeo.blob.core.windows.net/masaccesosbeneficios/iconos/Redessociales/Instagram.png
redes/Tiktok.png: https://storageproyectosmercadeo.blob.core.windows.net/masaccesosbeneficios/iconos/Redessociales/Tiktok.png
redes/Youtube.png: https://storageproyectosmercadeo.blob.core.windows.net/masaccesosbeneficios/iconos/Redessociales/Youtube.png
redes/Linkedin.png: https://storageproyectosmercadeo.blob.core.windows.net/masaccesosbeneficios/iconos/Redessociales/Linkedin.png


