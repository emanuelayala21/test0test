import TarjetaBeneficio from './TarjetaBeneficio.jsx'

export default function ListaBeneficios({ visibles, total, cargando, error, texto, onBuscar, filtrado, onVerTodos }) {
  let contador = `Mostrando ${visibles.length} de ${total} beneficios`
  if (cargando) contador = 'Cargando beneficios...'
  if (error) contador = 'No se pudieron cargar los beneficios.'

  return (
    <section id="beneficios" className="beneficios py-5">
      <div className="container">
        {/* Título, contador y botón para ver todos */}
        <div className="d-flex flex-wrap justify-content-between align-items-end gap-2 mb-3">
          <div>
            <h2 className="seccion-titulo mb-1">Beneficios</h2>
            <p className="mb-0 text-muted" role="status" aria-live="polite">{contador}</p>
          </div>
          <button type="button" className="btn btn-outline-ande" onClick={onVerTodos} disabled={!filtrado}>
            Ver todos los beneficios
          </button>
        </div>

        {/* Buscador debajo del título */}
        <div className="buscador mb-4">
          <label htmlFor="busqueda" className="visually-hidden">Buscar comercio</label>
          <svg className="buscador-icono" viewBox="0 0 24 24" aria-hidden="true" focusable="false">
            <circle cx="11" cy="11" r="7" fill="none" stroke="currentColor" strokeWidth="2" />
            <path d="M16.5 16.5L21 21" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
          </svg>
          <input
            type="search"
            id="busqueda"
            className="form-control form-control-lg"
            placeholder="Buscar comercio, categoría o promoción..."
            autoComplete="off"
            value={texto}
            onChange={(e) => onBuscar(e.target.value)}
          />
        </div>

        {error && <div className="alert alert-danger" role="alert">{error}</div>}

        {!cargando && !error && visibles.length === 0 && (
          <div className="alert alert-info d-flex flex-wrap align-items-center justify-content-between gap-2" role="status">
            <span>No se encontraron beneficios con ese criterio.</span>
            <button type="button" className="btn btn-sm btn-ande" onClick={onVerTodos}>Ver todos</button>
          </div>
        )}

        {/* 1 columna en móvil, 2 en tablet, 4 en escritorio */}
        <div className="row row-cols-1 row-cols-sm-2 row-cols-lg-4 g-4">
          {visibles.map((b) => <TarjetaBeneficio key={b.id} beneficio={b} />)}
        </div>
      </div>
    </section>
  )
}
