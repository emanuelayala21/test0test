import { useEffect, useState } from 'react'
import ImagenSegura from './ImagenSegura.jsx'
import { LOGOS } from '../recursos.js'
const ENLACES = [
  { id: 'inicio', texto: 'Inicio' },
  { id: 'destacado', texto: 'Destacado' },
  { id: 'categorias', texto: 'Categorías' },
  { id: 'beneficios', texto: 'Beneficios' },
  { id: 'contacto', texto: 'Contacto' },
]

export default function Header() {

  // En el cel se cierra el menú después de elegir una opción
  const cerrarMenu = () => {
    const menu = document.getElementById('menuPrincipal')
    if (menu?.classList.contains('show') && window.bootstrap) {
      const instancia = window.bootstrap.Collapse.getInstance(menu) || new window.bootstrap.Collapse(menu, { toggle: false })
      instancia.hide()
    }
  }

  return (
    <header className="site-header sticky-top">
      <nav className="navbar navbar-expand-lg navbar-dark" aria-label="Navegación principal">
        <div className="container">
          <a className="navbar-brand d-flex align-items-center gap-3" href="#inicio">
            <ImagenSegura className="logo-ande" src={LOGOS.ande} alt="Caja de ANDE" modo="texto" claseTexto="fw-bold text-white" />
            <ImagenSegura className="logo-beneficios" src={LOGOS.beneficios} alt="Beneficios" modo="texto" claseTexto="fw-bold text-white" />
          </a>
          <button
            className="navbar-toggler"
            type="button"
            data-bs-toggle="collapse"
            data-bs-target="#menuPrincipal"
          >
            <span className="navbar-toggler-icon"></span>
          </button>
          <div className="collapse navbar-collapse" id="menuPrincipal">
            <ul className="navbar-nav ms-auto">
              {ENLACES.map(({ id, texto }) => (
                <li className="nav-item" key={id}>
                  <a
                    className={'nav-link'}
                    href={'#' + id}
                    onClick={cerrarMenu}
                  >
                    {texto}
                  </a>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </nav>
    </header>
  )
}
