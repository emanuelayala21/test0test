import { VIDEO } from '../recursos.js'

// Iconos de bootstrap 
const ICONOS_INDICADOR = {
  regalo: 'bi bi-gift',
  tienda: 'bi bi-shop',
  etiqueta: 'bi bi-tag',
}

function Indicador({ icono, valor, texto }) {
  return (
    <div className="col-4 d-flex">
      <div className="indicador w-100 h-100 d-flex flex-column align-items-center text-center">
        <span className="indicador-icono">
          <i
            className={ICONOS_INDICADOR[icono]}
            aria-hidden="true"
          ></i>
        </span>

        <span className="indicador-valor">{valor}</span>
        <span className="indicador-texto">{texto}</span>
      </div>
    </div>
  )
}

export default function Welcome({ indicadores, cargando }) {
  const v = (n) => (cargando ? '-' : n)
  return (
    <section id="inicio" className="welcome py-5">
      <div className="container">
        <div className="welcome-caja">
          <div className="row align-items-center g-4">
            <div className="col-lg-6">
              <span className="etiqueta-programa">Programa de beneficios tarjetahabientes</span>
              <h1 className="welcome-titulo">Más acceso, más beneficios.</h1>
              <p className="lead mb-0">Descuentos y promociones exclusivas en comercios aliados al pagar con sus tarjetas de Caja de ANDE.</p>
              {/* Indicadores calculados con el JSON */}
              <div className="row g-3 mt-3">
                <Indicador icono="regalo" valor={v(indicadores.total)} texto="Beneficios activos" />
                <Indicador icono="tienda" valor={v(indicadores.categorias)} texto="Categorías" />
                <Indicador icono="etiqueta" valor={v(indicadores.conDescuento)} texto="Con descuento %" />
              </div>
            </div>
            <div className="col-lg-6">
              <div className="ratio ratio-16x9 welcome-video">
                <video controls muted playsInline preload="metadata" >
                  <source src={VIDEO} type="video/mp4" />
                  El video no está disponible en este momento.
                </video>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
