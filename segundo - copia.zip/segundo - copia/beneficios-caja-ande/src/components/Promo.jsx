import ImagenSegura from './ImagenSegura.jsx'
import { BANNER_MUJER } from '../recursos.js'

export default function Promo({ beneficios, destacado, cargando, onVerCategoria }) {
  // Segundo destacado para la tarjeta pequeña del banner (distinto al principal)
  const secundario = beneficios.find((b) => destacado && b.id !== destacado.id)

  return (
    <section id="destacado" className="promo py-5">
      <div className="container">
        <div className="row g-4 align-items-stretch">
          {/* Izquierda: banner mujer con tarjeta + texto encima */}
          <div className="col-12 col-lg-6">
            <div className="promo-banner h-100">
              <div className="promo-banner-texto">
                <h2 className="promo-titulo">
                  Descuentos y promociones <span>especiales</span>
                </h2>
                <p className="mb-0">Pague con sus tarjetas de Caja de ANDE y ahorre en cada compra.</p>
              </div>
              <ImagenSegura
                src={BANNER_MUJER}
                alt="Mujer sosteniendo una tarjeta de Caja de ANDE"
                className="promo-banner-img"
                modo="ocultar"
              />
              {secundario && (
                <div className="promo-mini">
                  <ImagenSegura className="promo-mini-logo" src={secundario.urlLogo} alt="" modo="ocultar" />
                  <div>
                    <span className="promo-mini-etiqueta">Destacado principal</span>
                    <strong className="d-block">{secundario.nombre}</strong>
                    <small>{secundario.categoria}</small>
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Derecha: cintillo (35%) + beneficio destacado (65%) */}
          <div className="col-12 col-lg-6 promo-derecha">
            <div className="cintillo">
              <h3 className="cintillo-titulo">Comercios afiliados</h3>
              <marquee behavior="scroll" direction="left" scrollamount="5" aria-label="Comercios afiliados">
                {beneficios.map((b) => (
                  <span className="cintillo-item" key={b.id}>
                    <span className="cintillo-logo">
                      <ImagenSegura src={b.urlLogo} alt="" modo="texto" textoAlterno={b.nombre.charAt(0)} claseTexto="cintillo-inicial" />
                    </span>
                    <span className="cintillo-nombre">{b.nombre}</span>
                  </span>
                ))}
              </marquee>
            </div>

            <article className="destacado">
              {cargando || !destacado ? (
                <p className="m-0 p-4">{cargando ? 'Cargando...' : 'Beneficios no disponibles'}</p>
              ) : (
                <div className="row g-0 h-100">
                  <div className="col-12 col-md-6 destacado-info">
                    <div className="d-flex align-items-center gap-3 mb-3">
                      <ImagenSegura className="destacado-logo" src={destacado.urlLogo} alt={`Logo de ${destacado.nombre}`} modo="ocultar" />
                      <div>
                        <span className="destacado-categoria">{destacado.categoria}</span>
                        <h2 className="h3 mb-0 destacado-nombre">{destacado.nombre}</h2>
                      </div>
                    </div>
                    <p className="mb-4">{destacado.descripcionCorta}</p>
                    <button type="button" className="btn btn-ande" onClick={() => onVerCategoria(destacado.categoria)}>
                      Ver más en {destacado.categoria}
                    </button>
                  </div>
                  <div className="col-12 col-md-6 destacado-media">
                    <ImagenSegura className="destacado-img" src={destacado.urlImagenFondo || destacado.urlImagen} alt={`Imagen de ${destacado.nombre}`} />
                    <span className="destacado-badge">
                      <small>Hasta</small>
                      {destacado.textoPromocion}
                    </span>
                  </div>
                </div>
              )}
            </article>
          </div>
        </div>
      </div>
    </section>
  )
}
